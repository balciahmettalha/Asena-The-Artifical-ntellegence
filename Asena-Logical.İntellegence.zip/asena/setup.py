"""ASENA kurulum betiği.

Proje yapılandırması ``pyproject.toml`` içindedir; bu dosya klasik
``pip install .`` / ``python setup.py`` akışları için uyumluluk sağlar.
"""

from setuptools import setup

setup()
