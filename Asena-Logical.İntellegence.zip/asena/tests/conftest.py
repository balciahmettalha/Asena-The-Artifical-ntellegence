"""Ortak test donatıları.

Her test yalıtık bir veri dizininde (tmp_path) tam bir bilişsel çekirdek
açar; testler birbirinin verisini görmez.
"""

from __future__ import annotations

import pytest

from asena.core.cognitive_core import CognitiveCore


@pytest.fixture()
def cekirdek(tmp_path, monkeypatch):
    """Geçici veri dizininde açılmış tam çekirdek."""
    monkeypatch.setenv("ASENA_VERI_DIZINI", str(tmp_path))
    with CognitiveCore() as c:
        yield c
