"""Türkçe sözdizimi, eklenti sistemi ve yerel API davranışları."""

from __future__ import annotations

import pytest

from asena.core.exceptions import ConsentRequiredError
from asena.plugins import AsenaPlugin


def test_kok_ek_cozumlemesi(cekirdek):
    coz = cekirdek.motor("turkish_language").cozumle("kitaplar")
    assert coz.kok == "kitap"
    assert "ler" in coz.ekler
    assert coz.kok_bilinen


def test_ek_uretimi_unlu_uyumuna_uyar():
    from asena.knowledge.semantic_network import ek_uret

    assert ek_uret("su", "DIR") == "dur"       # sudur
    assert ek_uret("sıvı", "DIR") == "dır"     # sıvıdır
    assert ek_uret("kedi", "DIR") == "dir"     # kedidir
    assert ek_uret("ekmek", "DAN") == "ten"    # ekmekten (sert ünsüz)
    assert ek_uret("un", "DAN") == "dan"       # undan


def test_yazim_denetimi_turkce_calisir(cekirdek):
    dil = cekirdek.motor("turkish_language")
    assert dil.yazim_dogru_mu("kitap")
    assert not dil.yazim_dogru_mu("ktpqrxyz")


def test_soru_parcacigi_kelime_icinde_tetiklenmez(cekirdek):
    """'miyavlar' içindeki 'mı' soru parçacığı sayılmamalı."""
    yanit = cekirdek.dongu.calis("kedi miyavlar.")
    assert yanit.niyet == "bildirim"


def test_sohbet_modu_akil_yurutme_izi_verir(cekirdek):
    from asena.chat import ChatMode

    sohbet = ChatMode(cekirdek)
    sohbet.soyle("merhaba")
    iz = sohbet.soyle("/iz")
    assert "algıla" in iz
    sohbet.kapat()


def test_eklenti_yukleme_onay_gerektirir(cekirdek, tmp_path):
    """Kod çalıştırma onayı olmadan dizinden eklenti yüklenemez."""
    eklenti_dizini = tmp_path / "eklentiler"
    eklenti_dizini.mkdir()
    (eklenti_dizini / "ornek.py").write_text(
        "from asena.plugins import AsenaPlugin\n"
        "class Ornek(AsenaPlugin):\n"
        "    ad = 'ornek'\n"
        "    def baglan(self, ctx): self.ctx = ctx\n"
        "    def kapat(self): pass\n"
        "def eklenti_olustur(): return Ornek()\n",
        encoding="utf-8",
    )
    eklentiler = cekirdek.motor("plugin_system")
    with pytest.raises(ConsentRequiredError):
        eklentiler.dizinden_yukle(eklenti_dizini)

    from asena.core.consent import Eylem

    cekirdek.consent.izin_ver(Eylem.KOD_CALISTIRMA)
    yuklenen = eklentiler.dizinden_yukle(eklenti_dizini)
    assert yuklenen == ["ornek"]
    assert isinstance(eklentiler.getir("ornek"), AsenaPlugin)


def test_sozlesmesiz_eklenti_reddedilir(cekirdek):
    class Bozuk:
        ad = "bozuk"

    eklentiler = cekirdek.motor("plugin_system")
    with pytest.raises(Exception):
        eklentiler.ekle(Bozuk())


def test_api_sohbet_ve_durum(cekirdek):
    from asena.api.local_api import AsenaAPI

    api = AsenaAPI(cekirdek)
    yanit = api.sohbet("merhaba")
    assert "ASENA" in yanit["yanit"]
    assert 0.0 <= yanit["guven"] <= 1.0

    durum = api.durum()
    assert durum["motor_sayisi"] == 60
    assert "syntax_engine" in durum["motorlar"]
    api.kapat()


def test_api_kismi_girdi_on_islem_baslatir(cekirdek):
    from asena.api.local_api import AsenaAPI

    api = AsenaAPI(cekirdek)
    sonuc = api.kismi("su ne")
    assert sonuc["durum"] == "ön-işlem başlatıldı"
    api.kapat()
