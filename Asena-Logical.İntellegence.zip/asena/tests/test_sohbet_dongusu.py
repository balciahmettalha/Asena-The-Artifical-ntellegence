"""Bilişsel döngünün kullanıcıya görünen davranışları.

Her test, sistemin kamusal arayüzü olan ``CognitiveCore.dongu.calis``
üzerinden bir yeteneği doğrular; iç gerçekleştirime dokunmaz.
"""

from __future__ import annotations


def test_selamlamaya_turkce_karsilik_verir(cekirdek):
    yanit = cekirdek.dongu.calis("merhaba")
    assert yanit.niyet == "selamlasma"
    assert "ASENA" in yanit.metin
    assert yanit.guven > 0.5


def test_aritmetik_ifadeyi_adimlarla_cozer(cekirdek):
    yanit = cekirdek.dongu.calis("2 + 3 * 4 =")
    assert yanit.niyet == "hesaplama"
    assert "14" in yanit.metin


def test_dogrusal_denklem_sohbette_cozulur(cekirdek):
    yanit = cekirdek.dongu.calis("2x + 3 = 7")
    assert yanit.niyet == "hesaplama"
    assert "2.0" in yanit.metin


def test_degisken_atamasi_hesaplama_sayilmaz(cekirdek):
    yanit = cekirdek.dongu.calis("x = 42")
    assert yanit.niyet == "bildirim"
    assert "kaydettim" in yanit.metin


def test_bilinen_kavrami_tanimlar(cekirdek):
    yanit = cekirdek.dongu.calis("kedi nedir?")
    assert yanit.niyet == "tanim_sorusu"
    assert "hayvan" in yanit.metin


def test_neden_sorusuna_nedensellik_zinciriyle_yanit_verir(cekirdek):
    yanit = cekirdek.dongu.calis("neden yağmur yağar?")
    assert yanit.niyet == "neden_sorusu"
    assert "çünkü" in yanit.metin


def test_ogretilen_onermeyi_hatirlar_ve_tanimda_kullanir(cekirdek):
    """Kullanıcının öğrettiği önerme sonraki soruda yanıta dönüşür."""
    cekirdek.dongu.calis("at hayvandır")
    yanit = cekirdek.dongu.calis("at nedir?")
    assert "hayvan" in yanit.metin
    assert "At bir hayvandır." in yanit.metin


def test_yanit_bilissel_iz_tasir(cekirdek):
    """Şeffaflık ilkesi: her yanıt hangi adımlardan geçtiğini bilir."""
    yanit = cekirdek.dongu.calis("merhaba")
    adimlar = [adim for adim, _ in yanit.iz]
    assert "algıla" in adimlar
    assert "anla" in adimlar
    assert "öğren" in adimlar


def test_bilinmeyen_konuda_alçakgonullu_yanit_verir(cekirdek):
    yanit = cekirdek.dongu.calis("blorfang nedir?")
    assert yanit.guven < 0.5
    assert "bilgim yok" in yanit.metin or "öğrenilmesi gerek" in yanit.metin
