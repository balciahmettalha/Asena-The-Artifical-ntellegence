"""Bellek, eğitim ve kalıcılık davranışları."""

from __future__ import annotations

from asena.core.cognitive_core import CognitiveCore


def test_ogrenilen_bilgi_veritabanina_yazilir(cekirdek):
    bellek = cekirdek.motor("memory_engine")
    kimlik = bellek.bilgi_kaydet("at", "bir hayvan", kaynak="test")
    assert kimlik.startswith("KB-")
    assert bellek.bilgi_bul(kimlik) is not None


def test_bilinmeyen_kelime_merak_gundemine_duser(cekirdek):
    cekirdek.dongu.calis("blorfang parlaktır")
    merak = cekirdek.motor("curiosity_engine")
    assert any(k.konu == "blorfang" for k in merak.kuyruk)


def test_merak_onaysiz_arastirma_yapmaz(cekirdek):
    """Onay ilkesi: internet yetkisi verilmedikçe araştırma başlatılmaz."""
    merak = cekirdek.motor("curiosity_engine")
    mesaj = merak.arastirma_istegi("kuantum")
    assert "onay" in mesaj


def test_egitim_yeni_kelime_ve_iliski_ogrenir(cekirdek, tmp_path):
    korpus = tmp_path / "korpus"
    korpus.mkdir()
    (korpus / "ornek.txt").write_text(
        "Tavuk bir hayvandır. Tavuk yumurta yapar. "
        "Kedi süt içer. Köpek havlar.\n",
        encoding="utf-8",
    )
    from asena.training import Trainer

    rapor = Trainer(cekirdek).egit(str(korpus))
    assert rapor.dosya_sayisi == 1
    assert rapor.cumle_sayisi >= 4
    assert rapor.yeni_kelime >= 1      # 'tavuk', 'yumurta' gibi yeni kökler
    assert rapor.yeni_iliski >= 1
    assert not rapor.hatalar


def test_ogrenilen_iliski_yeniden_acilista_korunur(tmp_path, monkeypatch):
    """Bir oturumda öğrenilen bilgi, yeni oturumda da hatırlanır."""
    monkeypatch.setenv("ASENA_VERI_DIZINI", str(tmp_path))
    with CognitiveCore() as c1:
        c1.dongu.calis("sokrates insandır")
    with CognitiveCore() as c2:
        yanit = c2.dongu.calis("sokrates nedir?")
    assert "insan" in yanit.metin
