"""Bilgi grafiği, anlam ağı ve mantık motorunun kamusal davranışları."""

from __future__ import annotations


def test_bilgi_grafi_iliskiyi_kalici_saklar(cekirdek):
    graf = cekirdek.motor("knowledge_graph")
    graf.kenar_ekle("at", "hayvan", "ust_tur")
    assert graf.iliski_var_mi("at", "hayvan", "ust_tur")


def test_anlam_ag_turkce_cumle_uretir(cekirdek):
    cumleler = cekirdek.motor("semantic_network").acikla("kedi")
    assert any("hayvan" in cumle for cumle in cumleler)


def test_unlu_uyumu_bozuk_cumle_uretilmez(cekirdek):
    """Ek üretici büyük ünlü uyumuna uyar: 'sıvıdır', 'sıvıdir' değil."""
    cumleler = cekirdek.motor("semantic_network").acikla("su")
    assert any("sıvıdır" in cumle for cumle in cumleler)
    assert not any("sıvıdir" in cumle for cumle in cumleler)


def test_kavram_zinciri_ust_turlere_ulasir(cekirdek):
    zincir = cekirdek.motor("concept_engine").zincir("kedi")
    assert zincir[0] == "kedi"
    assert "hayvan" in zincir
    assert zincir.index("hayvan") < zincir.index("canlı")


def test_modus_ponens_yeni_olgu_turetir(cekirdek):
    """'sokrates insandır' + kural → 'sokrates ölümlüdür' türetilir."""
    sonuc = cekirdek.motor("logic_engine").process({
        "onermeler": ["sokrates insandır"],
        "kurallar": ["?x insandır => ?x ölümlüdür"],
    })
    assert sonuc.ok
    assert any("ölümlü" in o and "sokrates" in o for o in sonuc.data)


def test_modus_tollens_kosulu_elenir(cekirdek):
    """¬sonuç + (koşul → sonuç) somut kuralı → ¬koşul çıkarılır."""
    sonuc = cekirdek.motor("logic_engine").process({
        "islem": "tollens",
        "onermeler": ["¬sokrates ölümlüdür"],
        "kurallar": ["sokrates insandır => sokrates ölümlüdür"],
    })
    assert sonuc.ok
    assert any(o.startswith("¬") and "insandır" in o for o in sonuc.data)


def test_zit_nesneli_kayitlar_supheli_sayilir(cekirdek):
    """Aynı özne için zıt iki değer kaydedilmişse avcı bunu raporlar."""
    bilgiler = [
        {"id": "KB-1", "ozne": "oda", "yuklem": "sıcaklığı", "nesne": "sıcak",
         "guven": 0.9},
        {"id": "KB-2", "ozne": "oda", "yuklem": "sıcaklığı", "nesne": "soğuk",
         "guven": 0.9},
    ]
    sonuc = cekirdek.motor("contradiction_hunter").process(bilgiler)
    assert sonuc.ok
    assert any(s.tur == "zit_nesne" for s in sonuc.data)
