"""Uzman modüllerin kamusal davranışları: matematik, fizik, kodlama."""

from __future__ import annotations

import pytest


def test_dogrusal_denklem_cozulur_ve_dogrulanir(cekirdek):
    sonuc = cekirdek.motor("math_expert").process("2x + 3 = 7")
    assert sonuc.ok
    assert sonuc.data.sonuc == pytest.approx(2.0)
    assert sonuc.data.dogrulandi_mi


def test_ortuk_carpma_hesaplanir(cekirdek):
    sonuc = cekirdek.motor("math_expert").process("2(3) + 1")
    assert sonuc.ok
    assert sonuc.data.sonuc == pytest.approx(7.0)


def test_sifira_bolme_turkce_hata_verir(cekirdek):
    sonuc = cekirdek.motor("math_expert").process("5 / 0")
    assert not sonuc.ok
    assert any("Sıfıra bölme" in h for h in sonuc.errors)


def test_turev_adim_adim_gosterilir(cekirdek):
    sonuc = cekirdek.motor("math_expert").process("türev 3x^2 + 2x - 5")
    assert sonuc.ok
    assert sonuc.data.sonuc == "6x + 2"


def test_fizik_formulu_bilinmeyeni_cozer(cekirdek):
    sonuc = cekirdek.motor("physics_expert").process({"m": 2.0, "a": 3.0})
    assert sonuc.ok
    assert sonuc.data.deger == pytest.approx(6.0)
    assert sonuc.data.birim == "N"


def test_fizik_cozumu_anlamini_turkce_aciklar(cekirdek):
    sonuc = cekirdek.motor("physics_expert").process({"m": 2.0, "a": 3.0})
    assert sonuc.ok
    assert sonuc.data.anlam
    assert "Anlamı:" in sonuc.explanation


def test_kod_cozumleme_fonksiyonlari_bulur(cekirdek):
    kod = "def topla(a, b):\n    return a + b\n"
    sonuc = cekirdek.motor("coding_expert").process({"kod": kod})
    assert sonuc.ok
    assert "topla" in sonuc.data.fonksiyonlar


def test_degisken_varsayilan_parametre_uyarilir(cekirdek):
    kod = "def ekle(oge, liste=[]):\n    liste.append(oge)\n"
    sonuc = cekirdek.motor("coding_expert").process({"kod": kod})
    assert not sonuc.ok
    assert any("mutable default" in b for b in sonuc.data.bulgular)
