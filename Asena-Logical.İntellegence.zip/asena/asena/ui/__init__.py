"""Kullanıcı arayüzü katmanı: komut satırı istemcisi."""

from asena.ui.cli import CLI

__all__ = ["CLI"]
