"""Komut Satırı Arayüzü (CLI).

ASENA ile etkileşimin birincil yoludur. İki mod destekler:

- ``python -m asena`` → sohbet modu
- ``python -m asena egit <dizin>`` → eğitim modu

Girdi satır tabanlıdır; öngörülü düşünme (kullanıcı yazarken ön-işlem)
API katmanındaki ``/kismi`` ucu üzerinden de kullanılabilir.
"""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

from asena import __version__

if TYPE_CHECKING:
    from asena.core.cognitive_core import CognitiveCore

BANNER = f"""
╔══════════════════════════════════════════════════╗
║   ASENA — Bilişsel İşletim Sistemi  v{__version__}      ║
║   Yalnızca Türkçe · Sembolik AI · LLM'siz mimari  ║
╚══════════════════════════════════════════════════╝
Yardım için /yardım yazın, çıkmak için /çıkış.
"""


class CLI:
    """Metin tabanlı sohbet arayüzü."""

    def __init__(self, cekirdek: "CognitiveCore") -> None:
        self.cekirdek = cekirdek

    def calistir(self) -> int:
        """Sohbet döngüsünü başlatır; çıkış kodu döndürür."""
        from asena.chat import ChatMode

        sohbet = ChatMode(self.cekirdek)
        print(BANNER)
        try:
            while True:
                try:
                    metin = input("siz> ").strip()
                except EOFError:
                    break
                if not metin:
                    continue
                yanit = sohbet.soyle(metin)
                if yanit == "__CIKIS__":
                    print("asena> Görüşmek üzere! Öğrendiklerim belleğimde saklı.")
                    break
                print(f"asena> {yanit}")
        except KeyboardInterrupt:
            print("\nasena> Oturum kapatıldı.")
        finally:
            sohbet.kapat()
        return 0


def ana_fonksiyon(argv: list[str] | None = None) -> int:
    """``python -m asena`` giriş noktası."""
    from asena.core.cognitive_core import CognitiveCore
    from asena.training import Trainer

    args = list(sys.argv[1:] if argv is None else argv)
    with CognitiveCore() as cekirdek:
        if args and args[0] == "egit":
            kaynak = args[1] if len(args) > 1 else str(
                cekirdek.ayarlar.get("egitim.corpus_dizini", "veri/corpus")
            )
            print(f"Eğitim başlıyor: {kaynak}")
            rapor = Trainer(cekirdek).egit(kaynak)
            print(rapor.metin())
            for hata in rapor.hatalar:
                print(f"  hata: {hata}")
            return 0 if not rapor.hatalar else 1
        return CLI(cekirdek).calistir()
