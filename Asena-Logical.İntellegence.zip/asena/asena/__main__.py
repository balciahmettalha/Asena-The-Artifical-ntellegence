"""``python -m asena`` giriş noktası."""

from asena.ui.cli import ana_fonksiyon

if __name__ == "__main__":
    raise SystemExit(ana_fonksiyon())
