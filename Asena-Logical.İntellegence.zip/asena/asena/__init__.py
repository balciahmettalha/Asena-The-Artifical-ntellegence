"""ASENA — Bilişsel İşletim Sistemi (Cognitive Operating System).

Hazır büyük dil modeli kullanmadan; sembolik mantık, bilgi grafikleri ve
bilişsel mimari üzerine kurulu, modüler ve genişletilebilir bir yapay zekâ
platformu. Yalnızca Türkçe çalışır.
"""

__version__ = "0.1.0"
__author__ = "ASENA Geliştirme Ekibi"

__all__ = ["__version__", "__author__"]
