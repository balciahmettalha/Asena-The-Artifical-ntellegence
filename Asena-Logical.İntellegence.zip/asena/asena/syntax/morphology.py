"""Türkçe biçim bilgisi çözümleyici (Morphological Analyzer).

Kural tabanlıdır: büyük/küçük ünlü uyumu ile üretilmiş ek aileleri ve
çekirdek kök sözlüğü kullanılır. Çözümleme, bilinen en uzun kökü
seçerek sağdan sola ek zinciri ayrıştırır. Bilinmeyen kökler
``kok_bilinen=False`` ile işaretlenir ve merak motoruna aday olur.

Hazır kütüphane kullanılmaz; tüm kurallar bu dosyada tanımlıdır.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from asena.syntax.lexicon import KOK_SOZLUK


def tr_lower(metin: str) -> str:
    """Türkçeye özgü küçük harf dönüşümü (I→ı, İ→i)."""
    return metin.replace("I", "ı").replace("İ", "i").lower()


def tr_upper(metin: str) -> str:
    """Türkçeye özgü büyük harf dönüşümü (i→İ, ı→I)."""
    return metin.replace("i", "İ").replace("ı", "I").upper()


# ---------------------------------------------------------------------------
# Ek aileleri: kanonik ad → olası yazım biçimleri (ünlü uyumu + kaynaştırma)
# ---------------------------------------------------------------------------
EK_AILELERI: dict[str, tuple[str, ...]] = {
    # çoğul
    "ler": ("lar", "ler"),
    # iyelik
    "Im": ("ım", "im", "um", "üm", "m"),
    "In": ("ın", "in", "un", "ün", "n"),
    "si": ("sı", "si", "su", "sü"),
    "ImIz": ("ımız", "imiz", "umuz", "ümüz", "mız", "miz", "muz", "müz"),
    "InIz": ("ınız", "iniz", "unuz", "ünüz", "nız", "niz", "nuz", "nüz"),
    "larI": ("ları", "leri"),
    # hâl ekleri
    "yi": ("yı", "yi", "yu", "yü"),                      # belirtme (kaynaştırmalı)
    "yA": ("ya", "ye"),                                  # yönelme (kaynaştırmalı)
    "nIn": ("nın", "nin", "nun", "nün"),                 # tamlayan (kaynaştırmalı)
    "DA": ("da", "de", "ta", "te"),
    "DAn": ("dan", "den", "tan", "ten"),
    "lA": ("la", "le"),
    "cA": ("ca", "ce", "ça", "çe"),
    "ki": ("ki",),
    # fiil: mastar ve kip ekleri
    "mAk": ("mak", "mek"),
    "Iyor": ("ıyor", "iyor", "uyor", "üyor", "yor"),
    "DI": ("dı", "di", "du", "dü", "tı", "ti", "tu", "tü"),
    "mIs": ("mış", "miş", "muş", "müş"),
    "yAcAk": ("acak", "ecek", "yacak", "yecek"),
    "mAlI": ("malı", "meli"),
    "sA": ("sa", "se"),
    "Ar": ("ar", "er", "ır", "ir", "ur", "ür", "r"),
    # kişi ekleri (fiil)
    "k": ("k",),
    "Iz": ("ız", "iz", "uz", "üz"),
    "sIn": ("sın", "sin", "sun", "sün"),
    # sıfat/isim türetme
    "lIk": ("lık", "lik", "luk", "lük"),
    "lI": ("lı", "li", "lu", "lü"),
    "sIz": ("sız", "siz", "suz", "süz"),
    "cIk": ("cık", "cik", "cuk", "cük", "çık", "çik", "çuk", "çük"),
}

# Kanonik ada göre ek türü
EK_TURLERI: dict[str, str] = {
    "ler": "çoğul", "Im": "iyelik", "In": "iyelik", "si": "iyelik",
    "ImIz": "iyelik", "InIz": "iyelik", "larI": "iyelik",
    "yi": "belirtme", "yA": "yönelme", "nIn": "tamlayan", "DA": "bulunma",
    "DAn": "ayrılma", "lA": "araç", "cA": "benzerlik", "ki": "ilgi",
    "mAk": "mastar", "Iyor": "şimdiki_zaman", "DI": "geçmiş_zaman",
    "mIs": "öğrenilen_geçmiş", "yAcAk": "gelecek_zaman", "mAlI": "gereklilik",
    "sA": "dilek_koşul", "Ar": "geniş_zaman", "k": "kişi", "Iz": "kişi",
    "sIn": "emir", "lIk": "yapım", "lI": "yapım", "sIz": "yapım", "cIk": "yapım",
}

FIIL_EKLERI: frozenset[str] = frozenset(
    {"mAk", "Iyor", "DI", "mIs", "yAcAk", "mAlI", "sA", "Ar", "sIn"}
)

# Söyleşimsel kasılmalar: yazım → (kök, ekler)
OZEL_BICIMLER: dict[str, tuple[str, list[str]]] = {
    "diyor": ("de", ["Iyor"]), "diyorlar": ("de", ["Iyor", "ler"]),
    "yiyor": ("ye", ["Iyor"]), "yiyorlar": ("ye", ["Iyor", "ler"]),
}

# Yazımdan kanonik ada ters dizin (uzundan kısaya dene)
_YAZIM_SOZLUGU: dict[str, str] = {}
for _kanonik, _bicimler in EK_AILELERI.items():
    for _b in _bicimler:
        _YAZIM_SOZLUGU.setdefault(_b, _kanonik)
_EK_YAZIMLARI = sorted(_YAZIM_SOZLUGU, key=len, reverse=True)


@dataclass
class Cozumleme:
    """Tek kelimenin biçim bilgisi çözümlemesi."""

    yazim: str
    kok: str
    ekler: list[str] = field(default_factory=list)       # kanonik ek adları
    tur: str | None = None                                # isim | fiil | ...
    kok_bilinen: bool = False
    ozel_ad: bool = False

    @property
    def fiil_mi(self) -> bool:
        return self.tur == "fiil" or any(e in FIIL_EKLERI for e in self.ekler)

    @property
    def cogul_mu(self) -> bool:
        return "ler" in self.ekler


class MorphologicalAnalyzer:
    """Kural tabanlı Türkçe kök/ek çözümleyici."""

    def __init__(self, sozluk: dict[str, tuple[str, str]] | None = None) -> None:
        self._sozluk = sozluk if sozluk is not None else KOK_SOZLUK

    # ------------------------------------------------------------------ yardımcı
    def ek_zinciri_coz(self, kalan: str) -> list[str] | None:
        """Kalan parçayı soldan sağa ek zincirine ayırır.

        Tüm parça bilinen eklerle tüketilebiliyorsa kanonik ek listesi,
        aksi hâlde ``None`` döner.
        """
        ekler: list[str] = []
        i = 0
        while i < len(kalan):
            eslesti = False
            for bicim in _EK_YAZIMLARI:
                if kalan.startswith(bicim, i):
                    ekler.append(_YAZIM_SOZLUGU[bicim])
                    i += len(bicim)
                    eslesti = True
                    break
            if not eslesti:
                return None
        return ekler

    # ------------------------------------------------------------------ çözümle
    def cozumle(self, kelime: str) -> Cozumleme:
        """Kelimeyi kök + ek zinciri olarak çözümler."""
        ham = kelime.strip()
        if not ham:
            return Cozumleme(yazim=kelime, kok="", kok_bilinen=False)
        if ham.isdigit():
            return Cozumleme(yazim=ham, kok=ham, tur="sayı", kok_bilinen=True)

        ozel_ad = ham[0].isupper()
        kesme = "'" in ham
        if kesme:  # Ankara'da → Ankara + 'da
            kok_parca, ek_parca = ham.split("'", 1)
            ekler = self.ek_zinciri_coz(tr_lower(ek_parca)) or []
            return Cozumleme(
                yazim=ham, kok=kok_parca, ekler=ekler,
                tur="isim", kok_bilinen=True, ozel_ad=True,
            )

        kucuk = tr_lower(ham)
        if kucuk in OZEL_BICIMLER:
            kok, ekler = OZEL_BICIMLER[kucuk]
            return Cozumleme(yazim=ham, kok=kok, ekler=list(ekler),
                             tur="fiil", kok_bilinen=True, ozel_ad=ozel_ad)

        if kucuk in self._sozluk:
            tur, _ = self._sozluk[kucuk]
            return Cozumleme(yazim=ham, kok=kucuk, tur=tur,
                             kok_bilinen=True, ozel_ad=ozel_ad)

        # Bilinen en uzun kök + geçerli ek zinciri
        for i in range(len(kucuk) - 1, 1, -1):
            kok = kucuk[:i]
            if kok in self._sozluk:
                ekler = self.ek_zinciri_coz(kucuk[i:])
                if ekler is not None:
                    kok_turu = self._sozluk[kok][0]
                    tur = "fiil" if any(e in FIIL_EKLERI for e in ekler) else kok_turu
                    return Cozumleme(yazim=ham, kok=kok, ekler=ekler, tur=tur,
                                     kok_bilinen=True, ozel_ad=ozel_ad)

        # Bilinmeyen kök: ekleri sıyırarak kök adayı üret
        for i in range(len(kucuk) - 1, 1, -1):
            ekler = self.ek_zinciri_coz(kucuk[i:])
            if ekler:
                kok = kucuk[:i]
                tur = "fiil" if any(e in FIIL_EKLERI for e in ekler) else "isim"
                return Cozumleme(yazim=ham, kok=kok, ekler=ekler, tur=tur,
                                 kok_bilinen=False, ozel_ad=ozel_ad)
        return Cozumleme(yazim=ham, kok=kucuk, kok_bilinen=False, ozel_ad=ozel_ad)

    def kok_mu(self, kelime: str) -> bool:
        return tr_lower(kelime.strip()) in self._sozluk

    def anlam(self, kok: str) -> str | None:
        kayit = self._sozluk.get(tr_lower(kok))
        return kayit[1] if kayit else None

    def tur(self, kok: str) -> str | None:
        kayit = self._sozluk.get(tr_lower(kok))
        return kayit[0] if kayit else None

    def sozluk_buyut(self, kok: str, tur: str, anlam: str) -> None:
        """Öğrenilen yeni kökü çalışma sözlüğüne ekler."""
        self._sozluk[tr_lower(kok)] = (tur, anlam)
