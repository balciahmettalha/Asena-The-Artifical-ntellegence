"""Sözdizim Motoru (Syntax Engine).

Türkçe metni cümlelere ve kelimelere ayırır, her kelimeyi morfolojik
olarak çözümler ve anlam blokları (özne/nesne/yüklem grupları) üretir.
Sık yapılan çözümlemeler önbelleğe alınır (Syntax Önbelleği ilkesi).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from asena.engine.base import BaseEngine, EngineResult
from asena.syntax.morphology import Cozumleme, MorphologicalAnalyzer, tr_lower

_CUMLE_AYRACI = re.compile(r"(?<=[.!?…])\s+")
_TOKEN_KALIBI = re.compile(
    r"[A-Za-zÇĞİÖŞÜçğıöşüâîû0-9]+(?:'[A-Za-zÇĞİÖŞÜçğıöşü]+)?|[.,!?…:;()\"']"
)


@dataclass
class AnlamBlogu:
    """Cümledeki bir anlam bloğu (isim veya fiil öbeği)."""

    kelimeler: list[str]
    rol: str  # ozne | nesne | yuklem | zarf | belirtec
    kokler: list[str] = field(default_factory=list)


@dataclass
class Cumle:
    """Çözümlenmiş tek cümle."""

    ham: str
    tokenler: list[str]
    cozumlemeler: list[Cozumleme]
    bloklar: list[AnlamBlogu] = field(default_factory=list)
    soru_mu: bool = False


class SyntaxEngine(BaseEngine):
    """Cümle ayrıştırma ve anlam bloğu çıkarma motoru."""

    name = "syntax_engine"
    group = "syntax"

    def __init__(self, analizci: MorphologicalAnalyzer | None = None) -> None:
        super().__init__()
        self.analizci = analizci or MorphologicalAnalyzer()
        self._onbellek: dict[str, Cumle] = {}
        self._onbellek_siniri = 512

    # ------------------------------------------------------------------ parçala
    def cumlelere_ayir(self, metin: str) -> list[str]:
        parcalar = _CUMLE_AYRACI.split(metin.strip())
        return [p for p in (s.strip() for s in parcalar) if p]

    def tokenize(self, cumle: str) -> list[str]:
        return _TOKEN_KALIBI.findall(cumle)

    # ------------------------------------------------------------------ blokla
    def _blok_rolu(self, coz: Cozumleme) -> str:
        if coz.fiil_mi:
            return "yuklem"
        if "yönelme" in [self._ek_turu(e) for e in coz.ekler]:
            return "nesne"
        if coz.tur == "zarf":
            return "zarf"
        return "ozne"

    @staticmethod
    def _ek_turu(kanonik: str) -> str:
        from asena.syntax.morphology import EK_TURLERI

        return EK_TURLERI.get(kanonik, "")

    def _blokla(self, cozumlemeler: list[Cozumleme]) -> list[AnlamBlogu]:
        bloklar: list[AnlamBlogu] = []
        for coz in cozumlemeler:
            rol = self._blok_rolu(coz)
            if bloklar and rol == "ozne" and bloklar[-1].rol in {"ozne", "belirtec"}:
                bloklar[-1].kelimeler.append(coz.yazim)
                bloklar[-1].kokler.append(coz.kok)
            else:
                bloklar.append(
                    AnlamBlogu(kelimeler=[coz.yazim], rol=rol, kokler=[coz.kok])
                )
        # Yüklem sonda değilse en sondaki fiil köklü bloğu yüklem say
        for blok in reversed(bloklar):
            if blok.rol == "yuklem":
                bloklar.remove(blok)
                bloklar.append(blok)
                break
        return bloklar

    # ------------------------------------------------------------------ çözümle
    def cumle_cozumle(self, cumle: str) -> Cumle:
        """Tek cümleyi tokenlerine, çözümlemelerine ve bloklarına ayırır."""
        anahtar = tr_lower(cumle.strip())
        if anahtar in self._onbellek:
            return self._onbellek[anahtar]
        tokenler = [
            t for t in self.tokenize(cumle) if t not in ".,!?:;()\"'…"
        ]
        cozumlemeler = [self.analizci.cozumle(t) for t in tokenler]
        sonuc = Cumle(
            ham=cumle,
            tokenler=tokenler,
            cozumlemeler=cozumlemeler,
            bloklar=self._blokla(cozumlemeler),
            soru_mu=cumle.rstrip().endswith("?"),
        )
        if len(self._onbellek) >= self._onbellek_siniri:
            self._onbellek.pop(next(iter(self._onbellek)))
        self._onbellek[anahtar] = sonuc
        return sonuc

    def metin_cozumle(self, metin: str) -> list[Cumle]:
        return [self.cumle_cozumle(c) for c in self.cumlelere_ayir(metin)]

    # ------------------------------------------------------------------ motor
    def process(self, girdi: str, **kwargs: object) -> EngineResult:
        """Metni çözümler; ``Cumle`` listesi döndürür."""
        if not isinstance(girdi, str) or not girdi.strip():
            return EngineResult.hata("Boş girdi çözümlenemez.")
        cumleler = self.metin_cozumle(girdi)
        bilinmeyen = [
            c.kok
            for cumle in cumleler
            for c in cumle.cozumlemeler
            if not c.kok_bilinen and c.kok
        ]
        return EngineResult(
            data=cumleler,
            explanation=f"{len(cumleler)} cümle çözümlendi.",
            metadata={"bilinmeyen_kokler": sorted(set(bilinmeyen))},
        )
