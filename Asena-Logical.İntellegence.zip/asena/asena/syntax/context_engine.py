"""Bağlam Motoru (Context Engine).

Aynı kelimenin farklı anlamlarını bağlama göre seçer. Örnek: 'yüz'
kelimesi 'su' ile birlikteyse fiil (yüzmek), 'sayı' ile birlikteyse
sayı (100), 'insan' ile birlikteyse organ (insan yüzü) olarak çözümlenir.

Yöntem: her anlam için bağlam kelimeleriyle örtüşen anahtar kelime
sayısı üzerinden skorlama (kural tabanlı, öğrenilebilir).
"""

from __future__ import annotations

from asena.engine.base import BaseEngine, EngineResult
from asena.syntax.morphology import tr_lower

# Çok anlamlı kökler: kök → {anlam: bağlam anahtar kelimeleri}
COK_ANLAMLILAR: dict[str, dict[str, set[str]]] = {
    "yüz": {
        "organ (insan yüzü)": {"insan", "göz", "burun", "yüzü", "bakmak", "güzel"},
        "sayı (100)": {"sayı", "yüz", "bin", "rakam", "matematik"},
        "fiil (yüzmek)": {"su", "deniz", "havuz", "yüzmek", "kulaç"},
    },
    "kaz": {
        "hayvan": {"kanat", "tüy", "göl", "ördek"},
        "fiil (kazmak)": {"toprak", "kürek", "çukur", "kazmak"},
    },
    "dal": {
        "ağaç dalı": {"ağaç", "yaprak", "budak"},
        "bilim dalı": {"fizik", "matematik", "alan", "uzmanlık"},
        "fiil (dalmak)": {"su", "deniz", "dalmak", "derin"},
    },
    "çay": {
        "içecek": {"demlik", "bardak", "içmek", "şeker"},
        "akarsu": {"su", "nehir", "akmak", "kenar"},
    },
    "at": {
        "hayvan": {"binit", "eyyer", "dörtnala", "tay"},
        "fiil (atmak)": {"fırlat", "top", "uzağa"},
    },
}


class ContextEngine(BaseEngine):
    """Bağlama duyarlı anlam seçimi yapan motor."""

    name = "context_engine"
    group = "syntax"

    def anlam_sec(self, kok: str, baglam: list[str]) -> tuple[str, float]:
        """Kök için bağlama en uygun anlamı ve güven puanını döndürür."""
        kayit = COK_ANLAMLILAR.get(tr_lower(kok))
        if not kayit:
            return ("birincil anlam", 0.5)
        baglam_kucuk = {tr_lower(b) for b in baglam}
        en_iyi, en_iyi_skor = "birincil anlam", 0
        for anlam, anahtarlar in kayit.items():
            skor = len(baglam_kucuk & anahtarlar)
            if skor > en_iyi_skor:
                en_iyi, en_iyi_skor = anlam, skor
        guven = min(0.5 + 0.25 * en_iyi_skor, 0.95) if en_iyi_skor else 0.3
        return (en_iyi, guven)

    def process(self, girdi: dict, **kwargs: object) -> EngineResult:
        """``{"kok": ..., "baglam": [...]}`` girdisiyle anlam seçer."""
        kok = str(girdi.get("kok", ""))
        baglam = list(girdi.get("baglam", []))
        anlam, guven = self.anlam_sec(kok, baglam)
        return EngineResult(
            data={"kok": kok, "anlam": anlam},
            confidence=guven,
            explanation=f"'{kok}' bağlamda '{anlam}' olarak çözümlendi.",
        )
