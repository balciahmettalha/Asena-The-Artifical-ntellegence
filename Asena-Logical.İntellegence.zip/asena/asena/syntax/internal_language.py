"""İç Temsil Dili (Internal Language).

Türkçe yalnızca giriş ve çıkış katmanıdır; sistemin düşündüğü dil bu
dosyadaki kavram-ilişki-anlam-sonuç zinciridir. Her cümle niyet ve
üçlüler (özne-yüklem-nesne) biçiminde normalize edilir.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from asena.engine.base import BaseEngine, EngineResult
from asena.syntax.lexicon import SELAMLASMA, SORU_KOKLERI
from asena.syntax.morphology import tr_lower
from asena.syntax.syntax_engine import Cumle

_HESAP_KALIBI = re.compile(
    r"^\s*[\d\s+\-*/xX×÷^().,%]+(?:\s*=\s*[\d\s+\-*/xX×÷^().,%]*)?\s*\??$"
)
_KELIME_KALIBI = re.compile(r"[\wçğıöşüÇĞİÖŞÜ]+", re.UNICODE)
_ESTIR_KALIBI = re.compile(
    r"^(?P<degisken>[A-Za-zçğıöşüÇĞİÖŞÜ]+)\s*=\s*(?P<deger>.+)$"
)


@dataclass(frozen=True)
class Uclu:
    """Özne-yüklem-nesne üçlüsü: iç dilin temel önerme biçimi."""

    ozne: str
    yuklem: str
    nesne: str | None = None

    def onerme(self) -> str:
        parcalar = [self.ozne, self.nesne, self.yuklem]
        return " ".join(p for p in parcalar if p)


@dataclass
class IcTemsil:
    """Bir girdinin iç dildeki karşılığı."""

    ham_metin: str
    niyet: str                       # selamlasma | soru | tanim_sorusu | neden_sorusu
                                   # | hesaplama | emir | bildirim | kavram_sorusu
    ucluler: list[Uclu] = field(default_factory=list)
    kavramlar: list[str] = field(default_factory=list)
    deyimler: dict[str, str] = field(default_factory=dict)
    parametreler: dict[str, Any] = field(default_factory=dict)
    soru_mu: bool = False


class InternalLanguage(BaseEngine):
    """Çözümlenmiş cümleleri iç temsil diline çeviren motor."""

    name = "internal_language"
    group = "syntax"
    dependencies = ("syntax_engine",)

    # ------------------------------------------------------------------ niyet
    def niyet_belirle(self, metin: str, cumle: Cumle | None) -> str:
        kucuk = tr_lower(metin.strip())
        kokler = {c.kok for c in cumle.cozumlemeler} if cumle else set()
        kelimeler = set(_KELIME_KALIBI.findall(kucuk))
        if any(s in kucuk for s in SELAMLASMA):
            return "selamlasma"
        if (
            _HESAP_KALIBI.match(kucuk)
            and any(ch.isdigit() for ch in kucuk)
            and not _ESTIR_KALIBI.match(metin.strip())
        ):
            return "hesaplama"
        if "nedir" in kucuk or "kimdir" in kucuk:
            return "tanim_sorusu"
        if "neden" in kucuk or "niçin" in kucuk:
            return "neden_sorusu"
        soru_parcacigi = bool(kelimeler & {"mı", "mi", "mu", "mü"})
        if (
            kucuk.endswith("?")
            or (cumle and cumle.soru_mu)
            or (SORU_KOKLERI & kokler)
            or soru_parcacigi
        ):
            return "soru"
        if cumle:
            for c in cumle.cozumlemeler:
                if c.tur == "fiil" and not c.ekler and c.yazim == metin.split()[-1]:
                    return "emir"
        return "bildirim"

    # ------------------------------------------------------------------ üçlü
    def uclu_uret(self, cumle: Cumle) -> list[Uclu]:
        ozne = ""
        nesne: str | None = None
        yuklem = ""
        for blok in cumle.bloklar:
            if blok.rol == "ozne" and not ozne:
                ozne = " ".join(blok.kokler)
            elif blok.rol == "nesne" and nesne is None:
                nesne = " ".join(blok.kokler)
            elif blok.rol == "yuklem":
                yuklem = " ".join(blok.kokler)
        if not (ozne or yuklem):
            return []
        return [Uclu(ozne=ozne or "?", yuklem=yuklem or "var", nesne=nesne)]

    # ------------------------------------------------------------------ çeviri
    def cevir(self, metin: str, cumleler: list[Cumle] | None = None) -> IcTemsil:
        """Ham metni iç temsil diline çevirir."""
        cumle = cumleler[0] if cumleler else None
        niyet = self.niyet_belirle(metin, cumle)
        ucluler: list[Uclu] = []
        kavramlar: list[str] = []
        for c in cumleler or []:
            ucluler.extend(self.uclu_uret(c))
            kavramlar.extend(
                coz.kok
                for coz in c.cozumlemeler
                if coz.kok_bilinen and coz.kok and coz.kok not in SORU_KOKLERI
            )
        parametreler: dict[str, Any] = {}
        esitlik = _ESTIR_KALIBI.match(metin.strip())
        if esitlik and niyet == "bildirim":
            parametreler["atama"] = (
                tr_lower(esitlik.group("degisken")),
                esitlik.group("deger").strip(),
            )
        return IcTemsil(
            ham_metin=metin,
            niyet=niyet,
            ucluler=ucluler,
            kavramlar=sorted(set(kavramlar)),
            soru_mu=bool(cumle and cumle.soru_mu),
            parametreler=parametreler,
        )

    # ------------------------------------------------------------------ motor
    def process(self, girdi: Any, **kwargs: Any) -> EngineResult:
        """``(metin, cumleler)`` veya yalnız metin ile iç temsil üretir."""
        if isinstance(girdi, tuple):
            metin, cumleler = girdi
        else:
            metin, cumleler = str(girdi), None
        temsil = self.cevir(metin, cumleler)
        return EngineResult(
            data=temsil,
            explanation=f"Niyet: {temsil.niyet}; {len(temsil.ucluler)} üçlü üretildi.",
        )
