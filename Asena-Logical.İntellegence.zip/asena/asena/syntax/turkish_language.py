"""Türkçe Dil Motoru.

Kök bulma, ek analizi, cümle çözümleme, sözcük türü tespiti, deyim/atasözü
tanıma, yazım denetimi ve anlam çözümleme yeteneklerini tek arayüzde
toplar. İçeride :class:`MorphologicalAnalyzer` ve :class:`SyntaxEngine`
kullanır (derin modül: basit arayüz, derin uygulama).
"""

from __future__ import annotations

from difflib import get_close_matches

from asena.engine.base import BaseEngine, EngineResult
from asena.syntax.lexicon import ATASOZLERI, DEYIMLER, KOK_SOZLUK
from asena.syntax.morphology import Cozumleme, MorphologicalAnalyzer, tr_lower
from asena.syntax.syntax_engine import SyntaxEngine


class TurkishLanguageEngine(BaseEngine):
    """Türkçenin dil bilgisini tek noktadan sunan motor."""

    name = "turkish_language"
    group = "syntax"
    dependencies = ("syntax_engine",)

    def __init__(self, syntax: SyntaxEngine | None = None) -> None:
        super().__init__()
        self.syntax = syntax or SyntaxEngine()
        self._ekstra_kelimeler: set[str] = set()  # öğrenilen kelimeler

    # ------------------------------------------------------------- temel çözüm
    @property
    def analizci(self) -> MorphologicalAnalyzer:
        return self.syntax.analizci

    def cozumle(self, kelime: str) -> Cozumleme:
        return self.analizci.cozumle(kelime)

    def kok_bul(self, kelime: str) -> str:
        return self.analizci.cozumle(kelime).kok

    def ek_analizi(self, kelime: str) -> list[str]:
        return self.analizci.cozumle(kelime).ekler

    def tur_tespit(self, kelime: str) -> str | None:
        return self.analizci.cozumle(kelime).tur

    def anlam_cozumle(self, kelime: str) -> str | None:
        """Kelimenin kök anlamını döndürür."""
        return self.analizci.anlam(self.kok_bul(kelime))

    # ------------------------------------------------------------- deyim/atasözü
    def deyim_bul(self, metin: str) -> dict[str, str]:
        """Metinde geçen deyimleri açıklamalarıyla döndürür."""
        kucuk = tr_lower(metin)
        return {d: a for d, a in DEYIMLER.items() if d in kucuk}

    def atasozu_bul(self, metin: str) -> dict[str, str]:
        kucuk = tr_lower(metin)
        return {a: ac for a, ac in ATASOZLERI.items() if a in kucuk}

    # ------------------------------------------------------------- yazım denetimi
    def _kelime_havuzu(self) -> set[str]:
        return set(KOK_SOZLUK) | self._ekstra_kelimeler

    def yazim_dogru_mu(self, kelime: str) -> bool:
        coz = self.analizci.cozumle(kelime)
        return coz.kok_bilinen or coz.kok in self._kelime_havuzu()

    def yazim_oner(self, kelime: str, en_cok: int = 3) -> list[str]:
        """Yazımı bozuk kelimeye en yakın doğru biçimleri önerir."""
        kucuk = tr_lower(kelime.strip())
        return get_close_matches(kucuk, self._kelime_havuzu(), n=en_cok, cutoff=0.75)

    def kelime_ogren(self, kok: str, tur: str = "isim", anlam: str = "") -> None:
        """Yeni öğrenilen kelimeyi dil havuzuna ekler."""
        kucuk = tr_lower(kok)
        self._ekstra_kelimeler.add(kucuk)
        self.analizci.sozluk_buyut(kucuk, tur, anlam or "öğrenilen kelime")

    # ------------------------------------------------------------------ motor
    def process(self, girdi: str, **kwargs: object) -> EngineResult:
        """Kelime ya da metni bütün yönleriyle çözümler."""
        if not isinstance(girdi, str) or not girdi.strip():
            return EngineResult.hata("Boş girdi.")
        metin = girdi.strip()
        if " " not in metin:
            coz = self.cozumle(metin)
            return EngineResult(
                data={
                    "kok": coz.kok,
                    "ekler": coz.ekler,
                    "tur": coz.tur,
                    "anlam": self.analizci.anlam(coz.kok),
                    "bilinen": coz.kok_bilinen,
                    "oneriler": [] if coz.kok_bilinen else self.yazim_oner(metin),
                },
                explanation=f"'{metin}' çözümlendi.",
            )
        deyimler = self.deyim_bul(metin)
        atasozleri = self.atasozu_bul(metin)
        return EngineResult(
            data={"deyimler": deyimler, "atasozleri": atasozleri},
            explanation=(
                f"{len(deyimler)} deyim, {len(atasozleri)} atasözü tanındı."
            ),
        )
