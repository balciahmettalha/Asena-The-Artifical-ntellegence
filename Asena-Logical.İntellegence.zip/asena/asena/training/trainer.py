"""Eğitim Modu (Training Mode).

Metin korpusundan öğrenir: bilinmeyen kelimeleri kaydeder, aynı cümlede
geçen kavramlar arasında birliktelik ilişkileri kurar ve günlük rapor
üretir. Çok dosyalı korpuslar çok çekirdekli (multiprocessing)
işlenebilir; ilerleme olay veri yolundan izlenir.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from multiprocessing import Pool
from pathlib import Path
from typing import TYPE_CHECKING, Any

from asena.core.event_bus import Event
from asena.training.corpus_processor import CorpusProcessor

if TYPE_CHECKING:
    from asena.core.cognitive_core import CognitiveCore


@dataclass
class EgitimRaporu:
    """Tek eğitim oturumunun özeti."""

    dosya_sayisi: int = 0
    cumle_sayisi: int = 0
    yeni_kelime: int = 0
    yeni_iliski: int = 0
    sure_sn: float = 0.0
    hatalar: list[str] = field(default_factory=list)

    def metin(self) -> str:
        return (
            f"Eğitim tamamlandı: {self.dosya_sayisi} dosya, "
            f"{self.cumle_sayisi} cümle; {self.yeni_kelime} yeni kelime, "
            f"{self.yeni_iliski} yeni ilişki ({self.sure_sn:.1f} sn)."
        )


def _kelime_istatistik(dosya_metni: str) -> list[str]:
    """Alt süreçte çalışan hafif ön-işlem: kelime listesi çıkarır."""
    isleyici = CorpusProcessor()
    kelimeler: list[str] = []
    for cumle in isleyici.cumleler(dosya_metni):
        kelimeler.extend(isleyici.kelimeler(cumle))
    return kelimeler


class Trainer:
    """Korpus üzerinden öğrenme oturumu yürütür."""

    def __init__(self, cekirdek: "CognitiveCore") -> None:
        self.c = cekirdek
        self.isleyici = CorpusProcessor(
            int(cekirdek.ayarlar.get("egitim.parca_boyutu", 65536))
        )

    # ------------------------------------------------------------------ eğitim
    def egit(self, kaynak: str | Path) -> EgitimRaporu:
        """Dosya veya dizindeki tüm .txt dosyalarından öğrenir."""
        baslangic = time.time()
        rapor = EgitimRaporu()
        dosyalar = self.isleyici.dosyalari_bul(kaynak)
        rapor.dosya_sayisi = len(dosyalar)
        if not dosyalar:
            rapor.hatalar.append(f"Metin dosyası bulunamadı: {kaynak}")
            return rapor
        self.c.bus.publish(
            Event("egitim.basladi", {"dosya": len(dosyalar)}, source="trainer")
        )
        for dosya in dosyalar:
            try:
                self._dosya_egit(dosya, rapor)
            except OSError as exc:
                rapor.hatalar.append(f"{dosya.name}: {exc}")
        rapor.sure_sn = round(time.time() - baslangic, 2)
        self.c.bus.publish(
            Event("egitim.bitti", {"rapor": rapor.metin()}, source="trainer")
        )
        return rapor

    def _dosya_egit(self, dosya: Path, rapor: EgitimRaporu) -> None:
        bellek = self.c.motor("memory_engine")
        ogrenme = self.c.motor("learning_engine")
        dil = self.c.motor("turkish_language")
        for parca in self.isleyici.metin_akisi(dosya):
            for cumle in self.isleyici.cumleler(parca):
                rapor.cumle_sayisi += 1
                kelimeler = self.isleyici.kelimeler(cumle)
                bilinen_kokler: set[str] = set()
                for kelime in kelimeler:
                    coz = dil.cozumle(kelime)
                    if not coz.kok_bilinen:
                        if bellek.kelime_bul(coz.kok) is None:
                            bellek.kelime_kaydet(
                                coz.kok, kok=coz.kok,
                                tur=coz.tur or "isim",
                                anlam="korpustan öğrenildi",
                            )
                            dil.kelime_ogren(coz.kok, coz.tur or "isim",
                                             "korpustan öğrenildi")
                            rapor.yeni_kelime += 1
                    else:
                        bilinen_kokler.add(coz.kok)
                # Bilinen kavramlar arasında birliktelik ilişkisi
                for a, b in self.isleyici.birliktelikler(sorted(bilinen_kokler)):
                    graf = self.c.motor("knowledge_graph")
                    if not graf.iliski_var_mi(a, b, "birlikte"):
                        ogrenme.iliski_ogren(a, b, "birlikte", 0.5)
                        rapor.yeni_iliski += 1

    # ------------------------------------------------------------------ paralel
    def paralel_kelime_istatistik(self, dosyalar: list[Path]) -> list[list[str]]:
        """Çok çekirdekli kelime çıkarımı (büyük korpuslar için)."""
        if not self.c.ayarlar.get("performans.cok_cekirdek", True) or len(dosyalar) < 2:
            return [_kelime_istatistik(d.read_text(encoding="utf-8", errors="ignore"))
                    for d in dosyalar]
        with Pool() as havuz:
            return havuz.map(
                _kelime_istatistik,
                [d.read_text(encoding="utf-8", errors="ignore") for d in dosyalar],
            )
