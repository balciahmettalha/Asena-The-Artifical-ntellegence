"""Eğitim modu: Türkçe metin korpusundan öğrenme."""

from asena.training.corpus_processor import CorpusProcessor
from asena.training.trainer import EgitimRaporu, Trainer

__all__ = ["CorpusProcessor", "EgitimRaporu", "Trainer"]
