"""Korpus İşleyici (Corpus Processor).

Türkçe metin dosyalarını parçalar hâlinde okur, cümlelere böler ve her
cümleden kelime/ilişki adayları çıkarır. Büyük dosyalar bellek
dostudur; parça parça işlenir.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Iterator

from asena.syntax.morphology import tr_lower

_CUMLE_AYRACI = re.compile(r"(?<=[.!?…])\s+")
_KELIME = re.compile(r"[a-zçğıöşüâîû]+(?:'[a-zçğıöşü]+)?", re.IGNORECASE)


class CorpusProcessor:
    """Metin korpusunu cümle ve kelime akışına dönüştürür."""

    def __init__(self, parca_boyutu: int = 65536) -> None:
        self.parca_boyutu = parca_boyutu

    # ------------------------------------------------------------------ kaynak
    def dosyalari_bul(self, dizin: str | Path) -> list[Path]:
        """Dizindeki .txt dosyalarını döndürür."""
        yol = Path(dizin)
        if yol.is_file() and yol.suffix == ".txt":
            return [yol]
        if not yol.is_dir():
            return []
        return sorted(yol.rglob("*.txt"))

    def metin_akisi(self, dosya: Path) -> Iterator[str]:
        """Dosyayı parçalar hâlinde okur (bellek dostu)."""
        with open(dosya, encoding="utf-8", errors="ignore") as akim:
            while True:
                parca = akim.read(self.parca_boyutu)
                if not parca:
                    break
                yield parca

    def cumleler(self, metin: str) -> list[str]:
        return [
            c.strip() for c in _CUMLE_AYRACI.split(metin.strip())
            if len(c.strip()) > 2
        ]

    def kelimeler(self, cumle: str) -> list[str]:
        """Cümledeki kelime adaylarını küçük harfle döndürür."""
        return [tr_lower(k) for k in _KELIME.findall(cumle)]

    def birliktelikler(self, kelimeler: list[str],
                       pencere: int = 3) -> Iterator[tuple[str, str]]:
        """Aynı cümlede yakın geçen kelime çiftlerini üretir."""
        for i, a in enumerate(kelimeler):
            for b in kelimeler[i + 1: i + pencere + 1]:
                if a != b:
                    yield (a, b) if a < b else (b, a)
